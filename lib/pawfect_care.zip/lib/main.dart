import 'package:flutter/material.dart';

// Auth Screens
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/forgot_password_screen.dart';
import 'screens/change_password_screen.dart';

// Core Screens
import 'screens/home_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/schedule_screen.dart';
import 'screens/healthcare_screen.dart';
import 'screens/appointment_screen.dart';
import 'screens/premium_screen.dart'; // this one stays outside premium/
import 'screens/cart_screen.dart';
import 'screens/messages_screen.dart';
import 'screens/notification_screen.dart';

// Chat & Product Details
import 'screens/chat_screen.dart';
import 'screens/product_detail_screen.dart';
import 'screens/product_list_screen.dart';
import 'screens/models/product_model.dart';

// Product Categories
import 'screens/products/food_screen.dart';
import 'screens/products/toys_screen.dart';
import 'screens/products/clothes_screen.dart';
import 'screens/products/pharma_screen.dart';
import 'screens/products/treats_screen.dart';
import 'screens/products/accessories_screen.dart';
import 'screens/products/adoption_screen.dart';
import 'screens/products/houses_screen.dart';
import 'screens/products/more_screen.dart';
import 'screens/products/product_screen.dart';

// Appointment Sub Pages
import 'screens/dating_screen.dart';
import 'screens/grooming_screen.dart';
import 'screens/training_screen.dart';
import 'screens/more_services_screen.dart';
import 'screens/dormitory_screen.dart';

// Utilities
import 'screens/search_screen.dart';
import 'screens/edit_profile_screen.dart';
import 'screens/banner_redirect_screen.dart';
import 'screens/groomer_detail_screen.dart';
import 'screens/transaction_screen.dart';
import 'screens/map_screen.dart';

// Hospitals
import 'screens/appointments/hospital_list_screen.dart';

// Premium Services (inside premium/)
//import 'package:pawfect_care/screens/premium/dna_test_screen.dart';
//import 'package:pawfect_care/screens/premium/true_breed_test_screen.dart';
//import 'package:pawfect_care/screens/premium/lost_pet_finder_screen.dart';
//import 'package:pawfect_care/screens/premium/wearable_screen.dart';
//import 'screens/premium/vet_247_screen.dart';
//import 'screens/premium/pet_wallet_screen.dart';

void main() {
  runApp(PawfectCareApp());
}

class PawfectCareApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pawfect Care',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        scaffoldBackgroundColor: Colors.white,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/login',
      routes: {
        // Auth
        '/login': (context) => LoginScreen(),
        '/signup': (context) => SignupScreen(),
        '/forgot': (context) => ForgotPasswordScreen(),
        '/change-password': (context) => ChangePasswordScreen(),

        // Main
        '/home': (context) => HomeScreen(),
        '/profile': (context) => ProfileScreen(),
        '/schedule': (context) => ScheduleScreen(),
        '/healthcare': (context) => HealthcareScreen(),
        '/appointment': (context) => AppointmentScreen(),
        '/premium': (context) => PremiumScreen(),
        '/cart': (context) => CartScreen(),
        '/messages': (context) => MessagesScreen(),
        '/notifications': (context) => NotificationScreen(),

        // Product Categories
        '/food': (context) => FoodScreen(),
        '/toys': (context) => ToysScreen(),
        '/clothes': (context) => ClothesScreen(),
        '/pharma': (context) => PharmaScreen(),
        '/treats': (context) => TreatsScreen(),
        '/accessories': (context) => AccessoriesScreen(),
        '/adoption': (context) => AdoptionScreen(),
        '/houses': (context) => HousesScreen(),
        '/more': (context) => MoreScreen(),
        '/product': (context) => ProductScreen(),

        // General Product List
        '/productList': (context) => ProductListScreen(),

        // Chat
        '/chat': (context) => const ChatScreen(receiverName: 'Support'),

        // Hospital Routes
        '/hospital-online': (context) => HospitalListScreen(type: 'Online'),
        '/hospital-offline': (context) => HospitalListScreen(type: 'Offline'),

        // Appointment Pages
        '/dating': (context) => DatingScreen(),
        '/grooming': (context) => GroomingScreen(),
        '/training': (context) => TrainingScreen(),
        '/more-services': (context) => MoreServicesScreen(),
        '/dormitory': (context) => DormitoryScreen(),

        // Utilities
        '/search': (context) => SearchScreen(),
        '/edit-profile': (context) => EditProfileScreen(),
        '/banner-redirect': (context) => BannerRedirectScreen(),
        '/groomer-detail': (context) => GroomerDetailScreen(groomer: {}),
        '/transaction': (context) =>
            TransactionScreen(cartItems: [], totalAmount: 0),
        '/map': (context) => MapScreen(destination: ''),

        // Premium
        //'/dna_testing': (context) => DnaTestScreen(),
        //'/true_breed_test': (context) => TrueBreedTestScreen(),
        //'/lost_pet_finder': (context) => LostPetFinderScreen(),
        //'/wearable_devices': (context) => WearableScreen(),
        //'/24_7_vet_care': (context) => Vet247Screen(),
        //'/pet_wallet': (context) => PetWalletScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/select-hospital') {
          final args = settings.arguments as Map<String, dynamic>;
          return MaterialPageRoute(
            builder: (context) =>
                HospitalListScreen(type: args['type'] ?? 'Offline'),
          );
        }

        if (settings.name == '/productDetail') {
          final args = settings.arguments as Product;
          return MaterialPageRoute(
            builder: (context) => ProductDetailScreen(product: args),
          );
        }

        return null;
      },
    );
  }
}
