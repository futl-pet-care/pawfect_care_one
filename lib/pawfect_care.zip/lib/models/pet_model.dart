// lib/models/pet_model.dart

class Pet {
  final String name;
  final String breed;
  final String location;
  final String image;
  final bool isTrained;

  Pet({
    required this.name,
    required this.breed,
    required this.location,
    required this.image,
    required this.isTrained,
  });

  factory Pet.fromMap(Map<String, dynamic> data) {
    return Pet(
      name: data['name'] ?? '',
      breed: data['breed'] ?? '',
      location: data['location'] ?? '',
      image: data['image'] ?? '',
      isTrained: data['isTrained'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'breed': breed,
      'location': location,
      'image': image,
      'isTrained': isTrained,
    };
  }
}
