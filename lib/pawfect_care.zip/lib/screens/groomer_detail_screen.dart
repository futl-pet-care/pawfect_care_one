import 'package:flutter/material.dart';
import 'transaction_screen.dart';
import 'map_screen.dart';

class GroomerDetailScreen extends StatefulWidget {
  final Map<String, dynamic> groomer;

  const GroomerDetailScreen({required this.groomer, Key? key})
      : super(key: key);

  @override
  State<GroomerDetailScreen> createState() => _GroomerDetailScreenState();
}

class _GroomerDetailScreenState extends State<GroomerDetailScreen> {
  String selectedDate = 'Today';
  String selectedTime = '';
  final List<String> timeSlots = [
    '10:00 AM',
    '11:30 AM',
    '01:00 PM',
    '03:00 PM',
    '05:30 PM'
  ];

  void _proceedToTransaction() {
    if (selectedTime.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please select a time slot")),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TransactionScreen(
          cartItems: [
            {
              'name': widget.groomer['name'],
              'image': widget.groomer['image'],
              'price': widget.groomer['price'],
              'quantity': 1,
            },
          ],
          totalAmount: widget.groomer['price'].toDouble(),
        ),
      ),
    ).then((_) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => MapScreen(destination: widget.groomer['location']),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final groomer = widget.groomer;

    return Scaffold(
      appBar: AppBar(
        title: Text(groomer['name']),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              groomer['image'],
              width: double.infinity,
              height: 180,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                height: 180,
                color: Colors.grey[300],
                child: Center(child: Icon(Icons.image_not_supported, size: 40)),
              ),
            ),
            SizedBox(height: 16),
            Text("Location: ${groomer['location']}"),
            Text("Price: ₹${groomer['price']}"),
            SizedBox(height: 16),
            Row(
              children: ['Today', 'Tomorrow', 'Other'].map((day) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: ChoiceChip(
                    label: Text(day),
                    selected: selectedDate == day,
                    onSelected: (_) => setState(() => selectedDate = day),
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 10),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: timeSlots.map((time) {
                return ChoiceChip(
                  label: Text(time),
                  selected: selectedTime == time,
                  onSelected: (_) => setState(() => selectedTime = time),
                );
              }).toList(),
            ),
            Spacer(),
            Center(
              child: ElevatedButton(
                onPressed: _proceedToTransaction,
                child: Text('Confirm & Pay'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
