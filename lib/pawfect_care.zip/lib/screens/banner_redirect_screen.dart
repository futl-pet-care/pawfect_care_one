import 'package:flutter/material.dart';

class BannerRedirectScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final String title =
        ModalRoute.of(context)?.settings.arguments as String? ?? "Banner";

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(
        child: Text("Content for $title"),
      ),
    );
  }
}
