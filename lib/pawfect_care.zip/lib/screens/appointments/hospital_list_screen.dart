import 'package:flutter/material.dart';

class HospitalListScreen extends StatefulWidget {
  final String type;

  const HospitalListScreen({Key? key, required this.type}) : super(key: key);

  @override
  _HospitalListScreenState createState() => _HospitalListScreenState();
}

class _HospitalListScreenState extends State<HospitalListScreen> {
  late List<Map<String, String>> hospitals;
  List<Map<String, String>> filteredHospitals = [];

  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    hospitals = _getHospitalsByType(widget.type);
    filteredHospitals = hospitals;
    _searchController.addListener(_filterHospitals);
  }

  List<Map<String, String>> _getHospitalsByType(String type) {
    if (type == 'Online') {
      return [
        {'name': 'Online Vet Dr. Ahuja', 'specialist': 'Video Consultation'},
        {'name': 'TeleVet Clinic', 'specialist': 'Remote Diagnostics'},
        {'name': 'Virtual Pet Meds', 'specialist': 'Online Rx & Follow-up'},
      ];
    } else {
      return [
        {'name': 'Happy Paws Hospital', 'specialist': '24x7 Emergency'},
        {'name': 'PetCare Clinic', 'specialist': 'Vaccination & Surgery'},
        {'name': 'FurEver Hospital', 'specialist': 'Dental & Grooming'},
      ];
    }
  }

  void _filterHospitals() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      filteredHospitals = hospitals.where((hospital) {
        final name = hospital['name']!.toLowerCase();
        final specialist = hospital['specialist']!.toLowerCase();
        return name.contains(query) || specialist.contains(query);
      }).toList();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.type} Hospitals'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search hospitals...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredHospitals.length,
              itemBuilder: (context, index) {
                final hospital = filteredHospitals[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ListTile(
                    leading: Icon(Icons.local_hospital, color: Colors.teal),
                    title: Text(hospital['name'] ?? ''),
                    subtitle: Text(hospital['specialist'] ?? ''),
                    trailing: Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      // TODO: Navigate to hospital detail if needed
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
