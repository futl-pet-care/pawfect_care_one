import 'package:flutter/material.dart';

class DormitoryScreen extends StatelessWidget {
  final List<Map<String, dynamic>> dormitories = [
    {
      'name': 'Happy Paws Dormitory',
      'location': 'Chennai',
      'price': 1200,
      'image': 'assets/acc_houses.jpg',
    },
    {
      'name': 'Cozy Pet Stay',
      'location': 'Coimbatore',
      'price': 1000,
      'image': 'assets/acc.jpg',
    },
    {
      'name': 'Fur Friends Inn',
      'location': 'Madurai',
      'price': 900,
      'image': 'assets/acc_cloths.jpg',
    },
  ];

  void _bookNow(BuildContext context, Map<String, dynamic> dorm) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Booking confirmed at ${dorm['name']}')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: EdgeInsets.all(16),
      itemCount: dormitories.length,
      itemBuilder: (context, index) {
        final dorm = dormitories[index];
        return Card(
          margin: EdgeInsets.only(bottom: 16),
          elevation: 4,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                dorm['image'],
                width: 60,
                height: 60,
                fit: BoxFit.cover,
              ),
            ),
            title: Text(dorm['name'],
                style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${dorm['location']} • Rs. ${dorm['price']}'),
            trailing: ElevatedButton(
              onPressed: () => _bookNow(context, dorm),
              child: Text('Book'),
            ),
          ),
        );
      },
    );
  }
}
