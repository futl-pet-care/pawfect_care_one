import 'package:flutter/material.dart';

class MoreServicesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('More Pet Services')),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          ListTile(
            leading: Icon(Icons.hotel, color: Colors.teal),
            title: Text('Pet-Friendly Hotels'),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.home, color: Colors.teal),
            title: Text('Pet-Friendly Houses'),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.pets, color: Colors.teal),
            title: Text('Lost Pet Finder'),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.local_fire_department, color: Colors.teal),
            title: Text('Cremation Services'),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.emoji_events, color: Colors.teal),
            title: Text('Competitions & Challenges'),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.campaign, color: Colors.teal),
            title: Text('Real World Campaigns'),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}
