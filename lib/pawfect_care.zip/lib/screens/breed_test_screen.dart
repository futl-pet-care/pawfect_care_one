// breed_test_screen.dart
import 'package:flutter/material.dart';

class BreedTestPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('True Breed Test')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            'Verify the authenticity of your pet’s breed with lab-certified reports.',
            style: TextStyle(fontSize: 16),
          ),
        ),
      ),
    );
  }
}
