// file: lib/screens/product_detail_screen.dart
import 'package:flutter/material.dart';
import 'models/product_model.dart';
import 'transaction_screen.dart';
//import 'model/product_model.dart'; // ✅ CORRECT (inside /screens/)
//import '../models/product_model.dart';

class ProductDetailScreen extends StatelessWidget {
  final Product product;

  const ProductDetailScreen({Key? key, required this.product})
      : super(key: key);

  void goToTransaction(BuildContext context) {
    List<Map<String, dynamic>> cartItem = [
      {
        'id': product.id,
        'name': product.name,
        'image': product.imageUrl,
        'price': product.price,
        'quantity': 1,
        'category': product.category,
      }
    ];

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            TransactionScreen(cartItems: cartItem, totalAmount: product.price),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(product.name),
        leading: BackButton(),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Image.asset(product.imageUrl, height: 200, fit: BoxFit.cover),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(product.name,
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text("₹${product.price}", style: TextStyle(fontSize: 18)),
          ),
          Spacer(),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: () => goToTransaction(context),
              child: Text("Buy Now"),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          )
        ],
      ),
    );
  }
}
