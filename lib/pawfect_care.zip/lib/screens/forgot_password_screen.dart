// file: lib/screens/forgot_password_screen.dart
import 'package:flutter/material.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final TextEditingController _email = TextEditingController();
  final TextEditingController _otp = TextEditingController();
  final TextEditingController _newPassword = TextEditingController();

  bool otpSent = false;
  bool otpVerified = false;

  void sendOtp() {
    setState(() {
      otpSent = true;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text("OTP sent (use 1234)")));
  }

  void verifyOtp() {
    if (_otp.text == "1234") {
      setState(() {
        otpVerified = true;
      });
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("OTP Verified")));
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("Invalid OTP")));
    }
  }

  void resetPassword() {
    if (_newPassword.text.length >= 6) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Password Reset Successful")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Forgot Password")),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(
                controller: _email,
                decoration: const InputDecoration(labelText: 'Email'),
                enabled: !otpSent),
            const SizedBox(height: 20),
            if (!otpSent)
              ElevatedButton(onPressed: sendOtp, child: const Text('Send OTP')),
            if (otpSent && !otpVerified) ...[
              TextField(
                  controller: _otp,
                  decoration: const InputDecoration(labelText: 'Enter OTP')),
              const SizedBox(height: 10),
              ElevatedButton(
                  onPressed: verifyOtp, child: const Text('Verify OTP')),
            ],
            if (otpVerified) ...[
              TextField(
                  controller: _newPassword,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'New Password')),
              const SizedBox(height: 10),
              ElevatedButton(
                  onPressed: resetPassword,
                  child: const Text('Reset Password')),
            ],
          ],
        ),
      ),
    );
  }
}
