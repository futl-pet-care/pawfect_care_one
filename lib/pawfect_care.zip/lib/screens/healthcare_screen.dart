import 'package:flutter/material.dart';

class HealthcareScreen extends StatelessWidget {
  const HealthcareScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Healthcare Consultation"),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionTitle("Consult a Vet (Online)"),
            _onlineConsultationCard(context),
            const SizedBox(height: 24),
            _sectionTitle("Visit a Clinic (Offline)"),
            _offlineClinicCard(context),
            const SizedBox(height: 24),
            _sectionTitle("Past Consultations"),
            _pastConsultationsList(),
            const SizedBox(height: 24),
            _sectionTitle("Upload Reports or Symptoms"),
            _uploadSection(),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
    );
  }

  Widget _onlineConsultationCard(BuildContext context) {
    return Card(
      elevation: 4,
      child: ListTile(
        leading: const Icon(Icons.video_call, color: Colors.deepPurple),
        title: const Text("Online Vet Consultation"),
        subtitle: const Text("Talk to a certified vet now"),
        trailing: ElevatedButton(
          onPressed: () {
            Navigator.pushNamed(
              context,
              '/select-hospital',
              arguments: {'type': 'Online'},
            );
          },
          style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
          child: const Text("Book Now"),
        ),
      ),
    );
  }

  Widget _offlineClinicCard(BuildContext context) {
    return Card(
      elevation: 4,
      child: ListTile(
        leading: const Icon(Icons.location_on, color: Colors.deepPurple),
        title: const Text("Nearby Pet Clinics"),
        subtitle: const Text("Find and visit pet hospitals"),
        trailing: ElevatedButton(
          onPressed: () {
            Navigator.pushNamed(
              context,
              '/select-hospital',
              arguments: {'type': 'Offline'},
            );
          },
          style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
          child: const Text("Find"),
        ),
      ),
    );
  }

  Widget _pastConsultationsList() {
    final pastData = [
      {"date": "June 1, 2025", "vet": "Dr. Mehta", "mode": "Online"},
      {"date": "May 24, 2025", "vet": "Dr. Singh", "mode": "Clinic"},
    ];

    return Column(
      children: pastData.map((item) {
        return ListTile(
          leading: const Icon(Icons.history, color: Colors.grey),
          title: Text("${item["vet"]} - ${item["mode"]}"),
          subtitle: Text(item["date"]!),
        );
      }).toList(),
    );
  }

  Widget _uploadSection() {
    return Column(
      children: [
        OutlinedButton.icon(
          onPressed: () {},
          icon: const Icon(Icons.upload_file),
          label: const Text("Upload Image or Report"),
        ),
        const SizedBox(height: 8),
        TextField(
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: "Describe symptoms...",
            border: OutlineInputBorder(),
          ),
        ),
      ],
    );
  }
}
