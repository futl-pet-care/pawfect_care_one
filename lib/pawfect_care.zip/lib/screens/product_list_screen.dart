// file: lib/screens/product_list_screen.dart
import 'package:flutter/material.dart';
import 'package:pawfect_care/screens/models/product_model.dart';
import 'package:pawfect_care/screens/product_detail_screen.dart';
//import 'package:pawfect_care/models/product_model.dart';

//import 'product_detail_screen.dart';
//import 'model/product_model.dart'; // ✅ CORRECT (inside /screens/)
//import '../models/product_model.dart';

class ProductListScreen extends StatelessWidget {
  final List<Product> products = [
    Product(
      id: '1',
      name: 'Dog Food - Chicken',
      imageUrl: 'assets/food_dog_chicken.png',
      price: 299,
      category: 'Food',
    ),
    Product(
      id: '2',
      name: 'Ball Toy',
      imageUrl: 'assets/toy_ball.png',
      price: 149,
      category: 'Toys',
    ),
    // Add more products as needed
  ];

  void _goToProductDetail(BuildContext context, Product product) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProductDetailScreen(product: product),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("All Products")),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return GestureDetector(
            onTap: () => _goToProductDetail(context, product),
            child: Card(
              margin: EdgeInsets.all(8),
              child: ListTile(
                leading: Image.asset(product.imageUrl, width: 50, height: 50),
                title: Text(product.name),
                subtitle: Text("₹${product.price}"),
                trailing: Icon(Icons.arrow_forward_ios, size: 16),
              ),
            ),
          );
        },
      ),
    );
  }
}
