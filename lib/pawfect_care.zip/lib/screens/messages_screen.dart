import 'package:flutter/material.dart';
import 'chat_screen.dart'; // ✅ Make sure this import is valid

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Dummy chat data
    final List<Map<String, dynamic>> chats = [
      {
        'type': 'notification',
        'name': '🔔 Notifications',
        'message': 'Your vaccine report is ready!',
        'icon': Icons.notifications,
        'active': true,
      },
      {
        'name': 'Dr. Mehta (Vet)',
        'message': 'Upload the test result',
        'icon': Icons.person,
      },
      {
        'name': 'Pet Taxi Service',
        'message': 'Your pickup is confirmed',
        'icon': Icons.local_taxi,
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Messages'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context); // Back to previous screen
          },
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // AI Assistant pinned chat
          ListTile(
            leading: const CircleAvatar(
              backgroundColor: Colors.deepPurple,
              child: Icon(Icons.smart_toy, color: Colors.white),
            ),
            title: const Text('🤖 PawBot (AI Assistant)',
                style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: const Text('How can I help you today?'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      const ChatScreen(receiverName: 'PawBot (AI Assistant)'),
                ),
              );
            },
          ),
          const Divider(),

          // Notification - if active, show before others
          if (chats[0]['active'])
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: Colors.orangeAccent,
                child: Icon(Icons.notifications_active, color: Colors.white),
              ),
              title: Text(chats[0]['name'],
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(chats[0]['message']),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        const ChatScreen(receiverName: 'Notifications'),
                  ),
                );
              },
            ),

          // Remaining chats
          for (int i = 1; i < chats.length; i++)
            ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.purple.shade100,
                child: Text(chats[i]['name'][0]),
              ),
              title: Text(chats[i]['name'],
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(chats[i]['message']),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChatScreen(receiverName: chats[i]['name']),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}
