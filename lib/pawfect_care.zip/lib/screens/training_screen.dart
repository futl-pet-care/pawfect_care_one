import 'package:flutter/material.dart';

class TrainingScreen extends StatefulWidget {
  @override
  _TrainingScreenState createState() => _TrainingScreenState();
}

class _TrainingScreenState extends State<TrainingScreen> {
  int currentModule = 1;

  final List<Map<String, String>> trainingModules = [
    {
      'title': 'Module 1',
      'description':
          'This pet care training video provides a comprehensive guide to help pet owners ensure the health, happiness, and well-being of their furry companions. Basic training, medical checkups, and understanding pet behavior are included. The video offers practical tips and expert advice for both novice and experienced pet parents.'
    },
    {
      'title': 'Module 2',
      'description':
          'This video focuses on nutrition and grooming. It helps pet owners choose the right diet and grooming routines. Practical demonstrations are included.'
    },
    {
      'title': 'Module 3',
      'description':
          'This session emphasizes pet safety, vaccinations, microchipping, and outdoor activities. Tips for socializing pets are also provided.'
    },
  ];

  void nextModule() {
    if (currentModule < trainingModules.length) {
      setState(() {
        currentModule++;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final module = trainingModules[currentModule - 1];

    return Scaffold(
      // Removed AppBar if using bottom nav
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(module['title']!,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Container(
              height: 180,
              color: Colors.grey[300],
              child: Center(
                child: Icon(Icons.play_circle_fill,
                    size: 64, color: Colors.grey[700]),
              ),
            ),
            SizedBox(height: 16),
            Text("Description",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            SizedBox(height: 8),
            Text(module['description']!),
            SizedBox(height: 16),
            Text("Upload your practice video (optional)"),
            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(Icons.upload_file),
                  SizedBox(width: 10),
                  Expanded(child: Text("Upload Video")),
                  ElevatedButton(
                    onPressed: () {},
                    child: Text("Submit"),
                  )
                ],
              ),
            ),
            Spacer(),
            if (currentModule < trainingModules.length)
              Center(
                child: ElevatedButton(
                  onPressed: nextModule,
                  child: Text("Next Module"),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
