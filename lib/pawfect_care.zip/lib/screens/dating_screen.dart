import 'package:flutter/material.dart';

class DatingScreen extends StatelessWidget {
  final List<Map<String, dynamic>> nearbyPets = [
    {
      'name': 'Bella',
      'breed': 'Labrador',
      'location': 'Chennai',
      'image': 'assets/acc.jpg',
      'isTrained': true,
    },
    {
      'name': 'Max',
      'breed': 'Beagle',
      'location': 'Coimbatore',
      'image': 'assets/acc_cloths.jpg',
      'isTrained': false,
    },
    {
      'name': 'Daisy',
      'breed': 'Golden Retriever',
      'location': 'Madurai',
      'image': 'assets/acc_houses.jpg',
      'isTrained': true,
    },
  ];

  void _handleMessageTap(BuildContext context, bool isTrained) {
    if (isTrained) {
      Navigator.pushNamed(context, '/chat');
    } else {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Training Required'),
          content: Text(
              'Please complete the basic pet training before messaging other pets.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/training');
              },
              child: Text('Go to Training'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Removed AppBar if using bottom nav
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: nearbyPets.length,
          itemBuilder: (context, index) {
            final pet = nearbyPets[index];
            return Card(
              margin: EdgeInsets.only(bottom: 16),
              elevation: 4,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset(
                    pet['image'],
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) =>
                        Icon(Icons.image_not_supported),
                  ),
                ),
                title: Text(pet['name'],
                    style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${pet['breed']} • ${pet['location']}'),
                trailing: ElevatedButton(
                  onPressed: () => _handleMessageTap(context, pet['isTrained']),
                  child: Text('Message'),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
