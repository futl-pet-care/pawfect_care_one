import 'package:flutter/material.dart';

class TransactionScreen extends StatelessWidget {
  final List<Map<String, dynamic>> cartItems;
  final double totalAmount;

  const TransactionScreen({
    Key? key,
    required this.cartItems,
    required this.totalAmount,
  }) : super(key: key);

  void completeTransaction(BuildContext context) {
    // Replace with real transaction logic or Firebase payment gateway
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Payment Successful"),
        content: Text("Thank you for your purchase!"),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
            child: Text("Back to Home"),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Confirm Purchase"),
        leading: BackButton(),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: cartItems.length,
              itemBuilder: (context, index) {
                var item = cartItems[index];
                return ListTile(
                  leading: Image.asset(item['image'], height: 40, width: 40),
                  title: Text(item['name']),
                  trailing: Text("₹${item['price'] * (item['quantity'] ?? 1)}"),
                );
              },
            ),
          ),
          Divider(),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Text(
                  "Total: ₹$totalAmount",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () => completeTransaction(context),
                  child: Text("Pay Now"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green, // ✅ fixed here
                    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
