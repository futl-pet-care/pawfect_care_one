// screens/product_screen.dart
import 'package:flutter/material.dart';

class ProductScreen extends StatelessWidget {
  const ProductScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map?;

    return Scaffold(
      appBar: AppBar(title: Text(args?['name'] ?? 'Product')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (args?['image'] != null)
              Image.asset(args!['image'], height: 100),
            const SizedBox(height: 20),
            Text('Welcome to ${args?['name'] ?? 'Product'} section!',
                style: const TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
