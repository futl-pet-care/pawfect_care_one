import 'package:flutter/material.dart';

class TreatsScreen extends StatelessWidget {
  const TreatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Treats')),
      body: const Center(child: Text('Pet Treats Page')),
    );
  }
}
