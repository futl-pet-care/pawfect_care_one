import 'package:flutter/material.dart';

class ToysScreen extends StatelessWidget {
  const ToysScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Toys')),
      body: const Center(child: Text('Toys Products Page')),
    );
  }
}
