import 'package:flutter/material.dart';

class PharmaScreen extends StatelessWidget {
  const PharmaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Pharma")),
      body: const Center(child: Text("Pharma products listed here")),
    );
  }
}
