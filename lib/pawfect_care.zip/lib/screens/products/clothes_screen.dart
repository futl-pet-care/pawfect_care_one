import 'package:flutter/material.dart';

class ClothesScreen extends StatelessWidget {
  const ClothesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Clothes")),
      body: const Center(child: Text("Clothing products listed here")),
    );
  }
}
