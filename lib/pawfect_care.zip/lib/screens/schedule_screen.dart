import 'package:flutter/material.dart';

class ScheduleScreen extends StatelessWidget {
  const ScheduleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            const Text("Pet Schedule", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Today's Overview",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _statCard(Icons.mood, "8.5 / 10", "Today's happiness score"),
                _statCard(Icons.restaurant, "550 kcal", "Food intake"),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _statCard(Icons.monitor_weight, "18.2", "BMI"),
                _statCard(
                    Icons.local_fire_department, "750 kcal", "Calorie intake"),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _statCard(Icons.kitchen, "1.2kg", "Remaining food"),
                _statCard(Icons.beach_access, "3 days", "Next vacation"),
              ],
            ),
            const SizedBox(height: 24),
            const Text("History",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _historyTile(
                "06 June 2025", "Scheduled Walk", Icons.directions_walk),
            _historyTile("05 June 2025", "Grooming Appointment", Icons.cut),
            _historyTile("04 June 2025", "Vet Visit", Icons.local_hospital),
            const SizedBox(height: 24),
            const Text("Upcoming",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _upcomingTile("10 June 2025", "Vaccination", Icons.medication),
            _upcomingTile("12 June 2025", "Spa Day", Icons.spa),
          ],
        ),
      ),
    );
  }

  Widget _statCard(IconData icon, String value, String label) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 6,
              offset: const Offset(0, 3),
            )
          ],
        ),
        child: Column(
          children: [
            Icon(icon, size: 30, color: Colors.deepPurple),
            const SizedBox(height: 8),
            Text(value,
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 4),
            Text(label,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12)),
          ],
        ),
      ),
    );
  }

  Widget _historyTile(String date, String title, IconData icon) {
    return ListTile(
      contentPadding:
          const EdgeInsets.symmetric(vertical: 4.0, horizontal: 0.0),
      leading: Icon(icon, color: Colors.deepPurple),
      title: Text(title),
      subtitle: Text(date),
      trailing: const Icon(Icons.check_circle, color: Colors.green),
    );
  }

  Widget _upcomingTile(String date, String title, IconData icon) {
    return ListTile(
      contentPadding:
          const EdgeInsets.symmetric(vertical: 4.0, horizontal: 0.0),
      leading: Icon(icon, color: Colors.deepPurple),
      title: Text(title),
      subtitle: Text(date),
      trailing: const Icon(Icons.access_time, color: Colors.orange),
    );
  }
}
