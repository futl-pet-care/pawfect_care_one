import 'package:flutter/material.dart';

class ProviderDashboardScreen extends StatelessWidget {
  final List<Map<String, dynamic>> services = [
    {
      'title': 'Delivery',
      'icon': Icons.delivery_dining,
      'route': '/provider-delivery',
    },
    {
      'title': 'Grooming',
      'icon': Icons.cut,
      'route': '/provider-grooming',
    },
    {
      'title': 'Dormitory',
      'icon': Icons.house,
      'route': '/provider-dormitory',
    },
    {
      'title': 'Training',
      'icon': Icons.school,
      'route': '/provider-training',
    },
    {
      'title': 'Hotels/Houses',
      'icon': Icons.hotel,
      'route': '/provider-hotel',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Provider Dashboard')),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: services.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, // two columns
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 1.1,
        ),
        itemBuilder: (context, index) {
          final service = services[index];
          return GestureDetector(
            onTap: () => Navigator.pushNamed(context, service['route']),
            child: Card(
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(service['icon'], size: 48, color: Colors.teal),
                  SizedBox(height: 12),
                  Text(
                    service['title'],
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
