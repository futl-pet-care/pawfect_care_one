import 'package:flutter/material.dart';

class DeliveryMapScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final String address =
        ModalRoute.of(context)?.settings.arguments as String? ??
            'Unknown Location';

    return Scaffold(
      appBar: AppBar(title: const Text("Delivery Location")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Icon(Icons.location_on, size: 100, color: Colors.teal),
            const SizedBox(height: 20),
            Text(
              "Delivery Address:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              address,
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: () {
                // Future: Open maps or mark delivered
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Opening Map for: $address")),
                );
              },
              icon: const Icon(Icons.map),
              label: const Text("Open in Maps"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                padding: const EdgeInsets.symmetric(
                  horizontal: 30,
                  vertical: 12,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
