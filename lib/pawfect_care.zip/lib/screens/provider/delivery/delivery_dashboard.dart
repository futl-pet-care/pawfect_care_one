import 'package:flutter/material.dart';

class DeliveryDashboard extends StatelessWidget {
  final List<Map<String, dynamic>> deliveries = [
    {
      'orderId': '#D1234',
      'address': '123, Anna Nagar, Chennai',
    },
    {
      'orderId': '#D1235',
      'address': '456, Gandhipuram, Coimbatore',
    },
    {
      'orderId': '#D1236',
      'address': '789, Tallakulam, Madurai',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Delivery Dashboard')),
      body: ListView.builder(
        itemCount: deliveries.length,
        padding: const EdgeInsets.all(12),
        itemBuilder: (context, index) {
          final delivery = deliveries[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            elevation: 3,
            child: ListTile(
              title: Text(delivery['orderId']),
              subtitle: Text(delivery['address']),
              trailing: IconButton(
                icon: const Icon(Icons.map, color: Colors.teal),
                onPressed: () {
                  Navigator.pushNamed(
                    context,
                    '/deliveryMap',
                    arguments: delivery['address'],
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
