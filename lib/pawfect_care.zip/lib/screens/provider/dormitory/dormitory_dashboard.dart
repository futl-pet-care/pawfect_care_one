import 'package:flutter/material.dart';
import 'dormitory_pet_profile.dart';
import 'dormitory_manage_food.dart';

class DormitoryDashboard extends StatelessWidget {
  final List<Map<String, dynamic>> dormitoryPets = [
    {
      'petName': 'Charlie',
      'age': '4 years',
      'breed': 'Golden Retriever',
      'image': 'assets/pets/dog1.png',
      'food': 'Dry Food',
    },
    {
      'petName': 'Luna',
      'age': '2 years',
      'breed': 'Persian Cat',
      'image': 'assets/pets/cat1.png',
      'food': 'Wet Food',
    },
  ];

  void _openPetProfile(BuildContext context, Map<String, dynamic> pet) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DormitoryPetProfile(pet: pet),
      ),
    );
  }

  void _manageFood(BuildContext context, Map<String, dynamic> pet) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DormitoryManageFood(pet: pet),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Dormitory Dashboard')),
      body: ListView.builder(
        itemCount: dormitoryPets.length,
        itemBuilder: (context, index) {
          final pet = dormitoryPets[index];
          return Card(
            margin: EdgeInsets.all(12),
            child: ListTile(
              leading: Image.asset(
                pet['image'],
                width: 50,
                height: 50,
                errorBuilder: (context, error, stackTrace) => Icon(Icons.pets),
              ),
              title: Text(pet['petName']),
              subtitle: Text('${pet['breed']} • ${pet['age']}'),
              trailing: PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'profile') {
                    _openPetProfile(context, pet);
                  } else if (value == 'food') {
                    _manageFood(context, pet);
                  }
                },
                itemBuilder: (context) => [
                  PopupMenuItem(
                    value: 'profile',
                    child: Text('View Profile'),
                  ),
                  PopupMenuItem(
                    value: 'food',
                    child: Text('Manage Food'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
