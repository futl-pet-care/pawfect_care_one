import 'package:flutter/material.dart';

class DormitoryManageFoodScreen extends StatefulWidget {
  final String petName;

  const DormitoryManageFoodScreen({Key? key, required this.petName})
      : super(key: key);

  @override
  State<DormitoryManageFoodScreen> createState() =>
      _DormitoryManageFoodScreenState();
}

class _DormitoryManageFoodScreenState extends State<DormitoryManageFoodScreen> {
  String selectedFood = 'Regular';

  final List<String> foodOptions = [
    'Regular',
    'Vegetarian',
    'Non-Vegetarian',
    'Grain-Free',
    'Custom Diet',
  ];

  void _saveFoodPreference() {
    // Save logic here, like sending to backend
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Food preference saved for ${widget.petName}'),
      ),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Manage Food for ${widget.petName}')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: selectedFood,
              items: foodOptions
                  .map((food) =>
                      DropdownMenuItem(value: food, child: Text(food)))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  selectedFood = value!;
                });
              },
              decoration: InputDecoration(
                labelText: 'Select Food Type',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _saveFoodPreference,
              icon: Icon(Icons.save),
              label: Text('Save Preference'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
              ),
            )
          ],
        ),
      ),
    );
  }
}
