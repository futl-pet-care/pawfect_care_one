import 'package:flutter/material.dart';

class TrainerUpdateProgressScreen extends StatefulWidget {
  final Map<String, dynamic> pet;

  const TrainerUpdateProgressScreen({Key? key, required this.pet})
      : super(key: key);

  @override
  _TrainerUpdateProgressScreenState createState() =>
      _TrainerUpdateProgressScreenState();
}

class _TrainerUpdateProgressScreenState
    extends State<TrainerUpdateProgressScreen> {
  double _progress = 0.5;
  final TextEditingController _notesController = TextEditingController();

  void _submitProgress() {
    // You would typically call an API to update progress here.
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Progress Updated"),
        content:
            Text("Training progress for ${widget.pet['name']} has been saved."),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.popUntil(context, (route) => route.isFirst),
            child: Text("Back to Dashboard"),
          )
        ],
      ),
    );
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Update Progress - ${widget.pet['name']}")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text("Progress",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Slider(
              value: _progress,
              onChanged: (value) => setState(() => _progress = value),
              min: 0,
              max: 1,
              divisions: 10,
              label: "${(_progress * 100).round()}%",
            ),
            SizedBox(height: 20),
            Text("Trainer Notes",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            TextField(
              controller: _notesController,
              maxLines: 4,
              decoration: InputDecoration(
                hintText:
                    "E.g., Very obedient. Learns quickly. Good with commands.",
                border: OutlineInputBorder(),
              ),
            ),
            Spacer(),
            ElevatedButton(
              onPressed: _submitProgress,
              child: Text("Submit Progress"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                minimumSize: Size(double.infinity, 48),
              ),
            )
          ],
        ),
      ),
    );
  }
}
