import 'package:flutter/material.dart';
import 'trainer_view_video.dart';
import 'trainer_update_progress.dart';

class TrainerDashboard extends StatelessWidget {
  final List<Map<String, dynamic>> assignedPets = [
    {
      'name': 'Buddy',
      'breed': 'Golden Retriever',
      'age': '1 year',
    },
    {
      'name': 'Luna',
      'breed': 'Labrador',
      'age': '2 years',
    },
    {
      'name': 'Max',
      'breed': 'German Shepherd',
      'age': '8 months',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Trainer Dashboard')),
      body: ListView.builder(
        itemCount: assignedPets.length,
        itemBuilder: (context, index) {
          final pet = assignedPets[index];
          return Card(
            margin: EdgeInsets.all(12),
            child: ListTile(
              title: Text(pet['name']),
              subtitle: Text('${pet['breed']} • ${pet['age']}'),
              trailing: PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'View Video') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => TrainerViewVideoScreen(pet: pet),
                      ),
                    );
                  } else if (value == 'Update Progress') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            TrainerUpdateProgressScreen(pet: pet),
                      ),
                    );
                  }
                },
                itemBuilder: (context) => [
                  PopupMenuItem(
                    value: 'View Video',
                    child: Text('View Training Video'),
                  ),
                  PopupMenuItem(
                    value: 'Update Progress',
                    child: Text('Update Progress'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
