import 'package:flutter/material.dart';

class TrainerViewVideoScreen extends StatelessWidget {
  final Map<String, dynamic> pet;

  const TrainerViewVideoScreen({Key? key, required this.pet}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Training Video - ${pet['name']}')),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            color: Colors.black12,
            height: 220,
            width: double.infinity,
            child: Icon(Icons.play_circle_fill, size: 80, color: Colors.teal),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              "Behavior Notes",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              "Trainer can observe obedience, aggression, response to commands, etc. You can update progress after review.",
              style: TextStyle(fontSize: 16),
            ),
          ),
          Spacer(),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(Icons.done_all),
              label: Text("Mark as Watched"),
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 48),
                backgroundColor: Colors.teal,
              ),
            ),
          )
        ],
      ),
    );
  }
}
