import 'package:flutter/material.dart';

class ProviderMessagesScreen extends StatelessWidget {
  const ProviderMessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> messages = [
      {
        'name': 'Ravi Kumar',
        'lastMessage': 'Thanks for the grooming session!',
        'time': '10:30 AM',
        'unread': true,
      },
      {
        'name': 'Meera Singh',
        'lastMessage': 'Will you be available tomorrow?',
        'time': 'Yesterday',
        'unread': false,
      },
      {
        'name': 'Arjun Das',
        'lastMessage': 'Thanks for the update on my pet.',
        'time': 'Mon',
        'unread': false,
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Messages"),
      ),
      body: ListView.separated(
        itemCount: messages.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final msg = messages[index];
          return ListTile(
            leading: CircleAvatar(
              child: Text(msg['name'][0]),
              backgroundColor: Colors.teal[200],
            ),
            title: Text(msg['name'],
                style: TextStyle(
                    fontWeight:
                        msg['unread'] ? FontWeight.bold : FontWeight.normal)),
            subtitle: Text(msg['lastMessage'],
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: Colors.grey[700])),
            trailing: Text(msg['time'],
                style: TextStyle(
                  fontSize: 12,
                  color: msg['unread'] ? Colors.teal : Colors.grey,
                )),
            onTap: () {
              Navigator.pushNamed(context, '/provider/chat',
                  arguments: msg['name']);
            },
          );
        },
      ),
    );
  }
}
