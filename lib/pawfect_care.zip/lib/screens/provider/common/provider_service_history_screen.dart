import 'package:flutter/material.dart';

class ProviderServiceHistoryScreen extends StatelessWidget {
  const ProviderServiceHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> serviceHistory = [
      {
        'petName': 'Tommy',
        'service': 'Grooming',
        'date': 'June 25, 2025',
        'status': 'Completed',
      },
      {
        'petName': 'Bella',
        'service': 'Dormitory',
        'date': 'June 20, 2025',
        'status': 'Completed',
      },
      {
        'petName': 'Simba',
        'service': 'Training',
        'date': 'June 15, 2025',
        'status': 'Completed',
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Service History"),
      ),
      body: ListView.builder(
        itemCount: serviceHistory.length,
        itemBuilder: (context, index) {
          final service = serviceHistory[index];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: ListTile(
              title: Text('${service['petName']} - ${service['service']}'),
              subtitle: Text('Date: ${service['date']}'),
              trailing: const Icon(Icons.check_circle, color: Colors.green),
            ),
          );
        },
      ),
    );
  }
}
