import 'package:flutter/material.dart';

class ProviderPaymentHistoryScreen extends StatelessWidget {
  const ProviderPaymentHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> paymentHistory = [
      {
        'date': 'June 26, 2025',
        'service': 'Grooming',
        'amount': 500,
        'status': 'Paid',
      },
      {
        'date': 'June 24, 2025',
        'service': 'Dormitory',
        'amount': 1200,
        'status': 'Paid',
      },
      {
        'date': 'June 21, 2025',
        'service': 'Training',
        'amount': 700,
        'status': 'Pending',
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Payment History"),
      ),
      body: ListView.builder(
        itemCount: paymentHistory.length,
        itemBuilder: (context, index) {
          final payment = paymentHistory[index];
          return ListTile(
            leading: Icon(
              payment['status'] == 'Paid' ? Icons.check_circle : Icons.pending,
              color: payment['status'] == 'Paid' ? Colors.green : Colors.orange,
            ),
            title: Text(payment['service']),
            subtitle: Text(payment['date']),
            trailing: Text(
              "₹${payment['amount']}",
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          );
        },
      ),
    );
  }
}
