import 'package:flutter/material.dart';

class ProviderProfileScreen extends StatelessWidget {
  const ProviderProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final providerInfo = {
      'name': 'John Doe',
      'role': 'Groomer',
      'phone': '+91 9876543210',
      'email': 'john@example.com',
      'location': 'Chennai, Tamil Nadu',
      'profileImage':
          'assets/provider_profile.png', // Replace with your asset path
    };

    return Scaffold(
      appBar: AppBar(
        title: const Text("Provider Profile"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 50,
              backgroundImage: AssetImage(providerInfo['profileImage']!),
            ),
            const SizedBox(height: 12),
            Text(
              providerInfo['name']!,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text(providerInfo['role']!,
                style: TextStyle(color: Colors.grey[600])),
            const Divider(height: 32),
            _buildInfoRow(Icons.phone, providerInfo['phone']!),
            _buildInfoRow(Icons.email, providerInfo['email']!),
            _buildInfoRow(Icons.location_on, providerInfo['location']!),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.edit),
              label: const Text("Edit Profile"),
              onPressed: () {
                Navigator.pushNamed(context, '/provider/edit-profile');
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, color: Colors.teal),
          const SizedBox(width: 12),
          Expanded(child: Text(value, style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }
}
