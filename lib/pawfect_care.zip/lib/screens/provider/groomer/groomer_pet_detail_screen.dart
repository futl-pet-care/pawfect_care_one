import 'package:flutter/material.dart';

class GroomerPetDetailScreen extends StatelessWidget {
  final Map<String, dynamic> appointment;

  const GroomerPetDetailScreen({Key? key, required this.appointment})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${appointment['petName']} Details')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Pet Name: ${appointment['petName']}',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Owner: ${appointment['owner']}'),
            Text('Appointment Time: ${appointment['time']}'),
            SizedBox(height: 16),
            Text('Vaccinated: ${appointment['vaccinated'] ? 'Yes' : 'No'}'),
            Text('Trained: ${appointment['trained'] ? 'Yes' : 'No'}'),
            Text('Violent Behavior: ${appointment['violent'] ? 'Yes' : 'No'}'),
            Spacer(),
            Center(
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Back'),
              ),
            )
          ],
        ),
      ),
    );
  }
}
