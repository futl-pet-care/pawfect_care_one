import 'package:flutter/material.dart';
import 'groomer_pet_detail_screen.dart';
import 'groomer_confirm_appointment.dart';

class GroomerDashboard extends StatelessWidget {
  final List<Map<String, dynamic>> appointments = [
    {
      'petName': 'Bruno',
      'owner': 'Ravi Kumar',
      'time': '10:00 AM',
      'trained': true,
      'vaccinated': true,
      'violent': false,
    },
    {
      'petName': 'Luna',
      'owner': 'Priya Sharma',
      'time': '11:30 AM',
      'trained': false,
      'vaccinated': true,
      'violent': false,
    },
  ];

  void _viewPetDetails(BuildContext context, Map<String, dynamic> appointment) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GroomerPetDetailScreen(appointment: appointment),
      ),
    );
  }

  void _confirmService(BuildContext context, Map<String, dynamic> appointment) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GroomerConfirmAppointment(appointment: appointment),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Groomer Dashboard')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: appointments.length,
        itemBuilder: (context, index) {
          final item = appointments[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            elevation: 3,
            child: ListTile(
              title: Text('${item['petName']} (${item['owner']})'),
              subtitle: Text('Time: ${item['time']}'),
              trailing: Wrap(
                spacing: 8,
                children: [
                  IconButton(
                    icon: Icon(Icons.info_outline),
                    onPressed: () => _viewPetDetails(context, item),
                  ),
                  IconButton(
                    icon: Icon(Icons.check_circle, color: Colors.teal),
                    onPressed: () => _confirmService(context, item),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
