import 'package:flutter/material.dart';

class GroomerConfirmAppointmentScreen extends StatelessWidget {
  final Map<String, dynamic> appointment;

  const GroomerConfirmAppointmentScreen({Key? key, required this.appointment})
      : super(key: key);

  void _confirmAppointment(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text('Appointment confirmed for ${appointment['petName']}')),
    );
    Navigator.pop(context);
  }

  void _rejectAppointment(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text('Appointment rejected for ${appointment['petName']}')),
    );
    Navigator.pop(context);
  }

  void _rescheduleAppointment(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Reschedule request sent')),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Confirm Appointment')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Pet Name: ${appointment['petName']}',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('Time: ${appointment['time']}'),
            Text('Owner: ${appointment['owner']}'),
            Text('Service: ${appointment['service']}'),
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => _confirmAppointment(context),
                  style:
                      ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  child: Text('Confirm'),
                ),
                ElevatedButton(
                  onPressed: () => _rejectAppointment(context),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: Text('Reject'),
                ),
                OutlinedButton(
                  onPressed: () => _rescheduleAppointment(context),
                  child: Text('Reschedule'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
