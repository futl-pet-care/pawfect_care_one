import 'package:flutter/material.dart';
import 'pet_hotel_room_detail.dart';

class PetHotelDashboard extends StatelessWidget {
  final List<Map<String, dynamic>> bookings = [
    {
      'petName': 'Shadow',
      'owner': 'Karthik',
      'room': 'Deluxe Room 1',
      'checkIn': '2025-07-01',
      'checkOut': '2025-07-03',
    },
    {
      'petName': 'Luna',
      'owner': 'Anjali',
      'room': 'Standard Room 2',
      'checkIn': '2025-07-05',
      'checkOut': '2025-07-07',
    },
  ];

  void _navigateToRoomDetail(
      BuildContext context, Map<String, dynamic> booking) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PetHotelRoomDetail(roomInfo: booking),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Pet Hotel Dashboard")),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: bookings.length,
        itemBuilder: (context, index) {
          final booking = bookings[index];
          return Card(
            margin: EdgeInsets.only(bottom: 16),
            child: ListTile(
              leading: Icon(Icons.pets),
              title: Text('${booking['petName']} - ${booking['room']}'),
              subtitle: Text(
                  'Owner: ${booking['owner']}\nCheck-in: ${booking['checkIn']} - Check-out: ${booking['checkOut']}'),
              trailing: Icon(Icons.arrow_forward_ios),
              onTap: () => _navigateToRoomDetail(context, booking),
            ),
          );
        },
      ),
    );
  }
}
