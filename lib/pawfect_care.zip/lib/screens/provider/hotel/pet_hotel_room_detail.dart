import 'package:flutter/material.dart';

class PetHotelRoomDetail extends StatelessWidget {
  final Map<String, dynamic> roomInfo;

  const PetHotelRoomDetail({Key? key, required this.roomInfo})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final petName = roomInfo['petName'];
    final owner = roomInfo['owner'];
    final room = roomInfo['room'];
    final checkIn = roomInfo['checkIn'];
    final checkOut = roomInfo['checkOut'];

    return Scaffold(
      appBar: AppBar(
        title: Text('$petName - Room Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Pet Name: $petName", style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text("Owner: $owner", style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text("Room Assigned: $room", style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text("Check-In: $checkIn", style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text("Check-Out: $checkOut", style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            Divider(),
            Text("Status & Services",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SwitchListTile(
              title: Text("Feeding Done"),
              value: true,
              onChanged: (val) {}, // Replace with backend update
            ),
            SwitchListTile(
              title: Text("Room Cleaned"),
              value: false,
              onChanged: (val) {}, // Replace with backend update
            ),
            SwitchListTile(
              title: Text("Daily Walk Given"),
              value: true,
              onChanged: (val) {}, // Replace with backend update
            ),
          ],
        ),
      ),
    );
  }
}
