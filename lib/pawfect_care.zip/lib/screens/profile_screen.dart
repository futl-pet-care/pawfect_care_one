import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.chat_bubble_outline),
            onPressed: () => Navigator.pushNamed(context, '/messages'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Profile picture
            Stack(
              children: [
                const CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.grey,
                  child: Icon(Icons.person, size: 50, color: Colors.white),
                ),
                Positioned(
                  bottom: 0,
                  right: 4,
                  child: ClipOval(
                    child: Container(
                      color: theme.primaryColor,
                      child: IconButton(
                        icon: const Icon(Icons.edit,
                            size: 20, color: Colors.white),
                        onPressed: () =>
                            Navigator.pushNamed(context, '/edit_profile'),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text('Ganesh Pawfect', style: theme.textTheme.titleLarge),
            const SizedBox(height: 4),
            const Text('ganesh@example.com',
                style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 4),
            const Text('📍 Hyderabad, Telangana',
                style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 24),

            // Stats cards
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: const [
                _StatCard(
                    icon: Icons.shopping_cart, label: 'Orders', value: '12'),
                _StatCard(icon: Icons.star_rate, label: 'Tier', value: 'Gold'),
                _StatCard(icon: Icons.pets, label: 'Pets', value: '2'),
              ],
            ),
            const SizedBox(height: 24),

            // Pet Info
            _sectionTitle('My Pets'),
            Card(
              child: ListTile(
                leading: const CircleAvatar(
                  radius: 25,
                  backgroundColor: Colors.grey,
                  child: Icon(Icons.pets, color: Colors.white),
                ),
                title: const Text('Max'),
                subtitle: const Text('Golden Retriever • 4 yrs'),
                trailing: IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => Navigator.pushNamed(context, '/edit_pet'),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Settings
            _sectionTitle('Settings & Info'),
            _buildTile(context, Icons.person, 'Edit Profile', '/edit_profile'),
            _buildTile(context, Icons.home, 'Change Address', '/addresses'),
            _buildTile(context, Icons.health_and_safety, 'Emergency Info',
                '/emergency'),
            _buildTile(context, Icons.chat, 'Chat with Vet', '/messages'),
            _buildTile(context, Icons.logout, 'Logout', '/login',
                replace: true),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        title,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildTile(
      BuildContext context, IconData icon, String title, String route,
      {bool replace = false}) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: () {
        if (replace) {
          Navigator.pushReplacementNamed(context, route);
        } else {
          Navigator.pushNamed(context, route);
        }
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _StatCard(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: theme.primaryColor.withOpacity(0.1),
          ),
          child: Icon(icon, size: 30, color: theme.primaryColor),
        ),
        const SizedBox(height: 6),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.grey)),
      ],
    );
  }
}
