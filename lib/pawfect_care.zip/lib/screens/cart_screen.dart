import 'package:flutter/material.dart';
import 'package:pawfect_care/screens/models/product_model.dart';
import 'package:pawfect_care/screens/product_detail_screen.dart';
import 'package:pawfect_care/screens/transaction_screen.dart';
//import '../models/product_model.dart'; // Make sure this path is correct

class CartScreen extends StatefulWidget {
  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  List<Map<String, dynamic>> cartItems = [];

  @override
  void initState() {
    super.initState();
    fetchCartItems();
  }

  void fetchCartItems() {
    setState(() {
      cartItems = [
        {
          'id': '1',
          'name': 'Dog Food (Beef)',
          'image': 'assets/food_dog_beef.png',
          'price': 349,
          'quantity': 2,
          'category': 'Food'
        },
        {
          'id': '2',
          'name': 'Chew Toy',
          'image': 'assets/toy_chew.png',
          'price': 199,
          'quantity': 1,
          'category': 'Toys'
        },
      ];
    });
  }

  double calculateTotal() {
    double total = 0;
    for (var item in cartItems) {
      total += item['price'] * item['quantity'];
    }
    return total;
  }

  void goToProductDetail(Map<String, dynamic> item) {
    final product = Product(
      id: item['id'],
      name: item['name'],
      imageUrl: item['image'],
      price: item['price'].toDouble(),
      category: item['category'],
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProductDetailScreen(product: product),
      ),
    );
  }

  void goToTransactionPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TransactionScreen(
          cartItems: cartItems,
          totalAmount: calculateTotal(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Your Cart"),
        leading: BackButton(),
      ),
      body: cartItems.isEmpty
          ? Center(child: Text("No items in cart, add something!"))
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: cartItems.length,
                    itemBuilder: (context, index) {
                      var item = cartItems[index];
                      return GestureDetector(
                        onTap: () => goToProductDetail(item),
                        child: Card(
                          margin: EdgeInsets.all(8),
                          child: ListTile(
                            leading: Image.asset(item['image'],
                                height: 50, width: 50),
                            title: Text(item['name']),
                            subtitle: Text("Qty: ${item['quantity']}"),
                            trailing:
                                Text("₹${item['price'] * item['quantity']}"),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Total: ₹${calculateTotal()}",
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      ElevatedButton(
                        onPressed: goToTransactionPage,
                        child: Text("Buy All"),
                      ),
                    ],
                  ),
                )
              ],
            ),
    );
  }
}
