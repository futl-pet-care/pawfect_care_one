// ✅ training_progress_screen.dart
import 'package:flutter/material.dart';

class TrainingProgressScreen extends StatefulWidget {
  const TrainingProgressScreen({Key? key}) : super(key: key);

  @override
  State<TrainingProgressScreen> createState() => _TrainingProgressScreenState();
}

class _TrainingProgressScreenState extends State<TrainingProgressScreen> {
  double progress = 0.3;

  void _uploadAssignment() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Assignment uploaded for certification!")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Training Progress")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            LinearProgressIndicator(value: progress),
            SizedBox(height: 16),
            Text("Current Progress: ${(progress * 100).round()}%"),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: _uploadAssignment,
              child: Text("Upload Assignment for Certification"),
            )
          ],
        ),
      ),
    );
  }
}
