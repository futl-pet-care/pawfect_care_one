// dna_testing_screen.dart
import 'package:flutter/material.dart';

class DNATestingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('DNA Testing')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            'Send in a sample to decode your pet’s genetic makeup. Results in 7 days.',
            style: TextStyle(fontSize: 16),
          ),
        ),
      ),
    );
  }
}
