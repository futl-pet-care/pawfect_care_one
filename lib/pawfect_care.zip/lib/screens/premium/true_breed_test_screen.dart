import 'package:flutter/material.dart';

class TrueBreedTestScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("True Breed Test")),
        body: Center(child: Text("Breed Test Info")));
  }
}
