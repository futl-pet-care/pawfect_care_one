// wallet_screen.dart
import 'package:flutter/material.dart';

class WalletPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Pet Wallet')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            'Track expenses, manage health records, and store all pet documents in one place.',
            style: TextStyle(fontSize: 16),
          ),
        ),
      ),
    );
  }
}
