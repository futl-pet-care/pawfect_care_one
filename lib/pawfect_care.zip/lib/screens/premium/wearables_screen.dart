// wearables_screen.dart
import 'package:flutter/material.dart';

class WearablesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Wearable Devices')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            'Smart collars and health bands to monitor pet activity and wellness.',
            style: TextStyle(fontSize: 16),
          ),
        ),
      ),
    );
  }
}
