import 'package:flutter/material.dart';

class MapScreen extends StatelessWidget {
  final String destination;

  MapScreen({required this.destination});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Track Location')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              Icon(Icons.map, size: 100, color: Colors.teal),
              SizedBox(height: 20),
              Text('Your groomer is on the way to $destination!',
                  style: TextStyle(fontSize: 18), textAlign: TextAlign.center),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () =>
                    Navigator.popUntil(context, (route) => route.isFirst),
                child: Text('Back to Home'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
