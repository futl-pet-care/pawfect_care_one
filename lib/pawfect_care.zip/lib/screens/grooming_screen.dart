import 'package:flutter/material.dart';

class GroomingScreen extends StatelessWidget {
  final List<Map<String, dynamic>> groomers = [
    {
      'name': 'Pet Style Salon',
      'location': 'Chennai',
      'price': 500,
      'image': 'assets/acc_treats.jpg',
    },
    {
      'name': 'Fluffy Spa',
      'location': 'Coimbatore',
      'price': 600,
      'image': 'assets/acc_cloths.jpg',
    },
    {
      'name': 'Wag & Wash',
      'location': 'Madurai',
      'price': 550,
      'image': 'assets/acc_houses.jpg',
    },
  ];

  void _bookNow(BuildContext context, Map<String, dynamic> groomer) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => GroomingBookingScreen(groomer: groomer),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Don't use AppBar if already present via navigation tab scaffold
      appBar: AppBar(title: Text('Grooming Services')),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: groomers.length,
        itemBuilder: (context, index) {
          final groomer = groomers[index];
          return Card(
            margin: EdgeInsets.only(bottom: 16),
            elevation: 4,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  groomer['image'],
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      Icon(Icons.image_not_supported),
                ),
              ),
              title: Text(
                groomer['name'],
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle:
                  Text('${groomer['location']} • Rs. ${groomer['price']}'),
              trailing: ElevatedButton(
                onPressed: () => _bookNow(context, groomer),
                child: Text('Book'),
              ),
            ),
          );
        },
      ),
    );
  }
}

class GroomingBookingScreen extends StatelessWidget {
  final Map<String, dynamic> groomer;

  GroomingBookingScreen({required this.groomer});

  void _confirmBooking(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Booking confirmed at ${groomer['name']}')),
    );

    // Optional: pop back after confirmation
    Future.delayed(Duration(seconds: 1), () => Navigator.pop(context));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Book Grooming')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              groomer['image'],
              width: double.infinity,
              height: 180,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Container(
                height: 180,
                color: Colors.grey[300],
                child: Center(child: Icon(Icons.image_not_supported, size: 40)),
              ),
            ),
            SizedBox(height: 16),
            Text(
              groomer['name'],
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text('Location: ${groomer['location']}'),
            SizedBox(height: 8),
            Text('Price: Rs. ${groomer['price']}'),
            Spacer(),
            Center(
              child: ElevatedButton(
                onPressed: () => _confirmBooking(context),
                child: Text('Confirm and Pay'),
              ),
            )
          ],
        ),
      ),
    );
  }
}
