import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  final List<Map<String, String>> categories = [
    {'title': 'Food', 'image': 'assets/food_icon.png'},
    {'title': 'Toys', 'image': 'assets/toys_icon.png'},
    {'title': 'House', 'image': 'assets/pet_house.png'},
    {'title': 'Adoption', 'image': 'assets/adoption_icon.png'},
    {'title': 'Cleaning', 'image': 'assets/cleaning.png'},
    {'title': 'Insurance', 'image': 'assets/insurance.png'},
    {'title': 'Pharma', 'image': 'assets/pharama.png'},
    {'title': 'Clothes', 'image': 'assets/clothes_icon.png'},
    {'title': 'Treats', 'image': 'assets/treats_icon.png'},
    {'title': 'More', 'image': 'assets/more.png'},
  ];

  final List<Map<String, String>> sampleProducts = List.generate(
    10,
    (index) => {
      'title': 'Product $index',
      'image': 'assets/sample_product.png',
      'price': '₹${(index + 1) * 100}'
    },
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _buildSearchBar(context),
            Expanded(
              child: ListView(
                children: [
                  _buildBannerSlider(context),
                  SizedBox(height: 10),
                  _buildCategoryGrid(context),
                  Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Text(
                      'Breed Specific',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  _buildProductGrid(context),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        selectedFontSize: 12,
        unselectedFontSize: 12,
        currentIndex: 0,
        onTap: (index) {
          switch (index) {
            case 1:
              Navigator.pushReplacementNamed(context, '/schedule');
              break;
            case 2:
              Navigator.pushReplacementNamed(context, '/healthcare');
              break;
            case 3:
              Navigator.pushReplacementNamed(context, '/appointment');
              break;
            case 4:
              Navigator.pushReplacementNamed(context, '/premium');
              break;
          }
        },
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.shopping_bag), label: 'E-commerce'),
          BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today), label: 'Schedule'),
          BottomNavigationBarItem(
              icon: Icon(Icons.local_hospital), label: 'Health care'),
          BottomNavigationBarItem(
              icon: Icon(Icons.healing), label: 'Appointments'),
          BottomNavigationBarItem(icon: Icon(Icons.star), label: 'Premium'),
        ],
      ),
    );
  }

  Widget _buildSearchBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: Colors.grey[200],
              ),
              child: Row(
                children: [
                  Icon(Icons.search),
                  SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      decoration: InputDecoration(
                          hintText: 'Search', border: InputBorder.none),
                    ),
                  ),
                ],
              ),
            ),
          ),
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () => Navigator.pushNamed(context, '/cart'),
          ),
          IconButton(
            icon: Icon(Icons.message),
            onPressed: () => Navigator.pushNamed(context, '/messages'),
          ),
          IconButton(
            icon: Icon(Icons.person),
            onPressed: () => Navigator.pushNamed(context, '/profile'),
          ),
        ],
      ),
    );
  }

  Widget _buildBannerSlider(BuildContext context) {
    final banners = [
      {'image': 'assets/banner1.png', 'route': '/premium'},
      {'image': 'assets/banner2.png', 'route': '/appointment'},
      {'image': 'assets/banner3.png', 'route': '/food'},
    ];

    return SizedBox(
      height: 160,
      child: PageView(
        children: banners.map((banner) {
          return GestureDetector(
            onTap: () => Navigator.pushNamed(context, banner['route']!),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  banner['image']!,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: Colors.grey[300],
                    child: Center(child: Text('Banner')),
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildCategoryGrid(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final int crossAxisCount = screenWidth < 360 ? 4 : 5;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: GridView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemCount: categories.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 0.7,
        ),
        itemBuilder: (context, index) {
          final cat = categories[index];
          return GestureDetector(
            onTap: () => Navigator.pushNamed(
              context,
              '/productList',
              arguments: {'category': cat['title']},
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundImage: AssetImage(cat['image']!),
                  backgroundColor: Colors.grey[200],
                  onBackgroundImageError: (_, __) {},
                ),
                SizedBox(height: 4),
                Text(
                  cat['title']!,
                  style: TextStyle(fontSize: 11),
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildProductGrid(BuildContext context) {
    return GridView.count(
      shrinkWrap: true,
      crossAxisCount: 2,
      physics: NeverScrollableScrollPhysics(),
      childAspectRatio: 0.75,
      padding: EdgeInsets.all(12),
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      children: sampleProducts.map((product) {
        return Card(
          elevation: 3,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Image.asset(
                  product['image']!,
                  fit: BoxFit.cover,
                  width: double.infinity,
                  errorBuilder: (_, __, ___) => Icon(Icons.image),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Text(product['title']!,
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Text(product['price']!),
              ),
              ButtonBar(
                alignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: Icon(Icons.add_shopping_cart),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Added to cart')),
                      );
                    },
                  ),
                  TextButton(
                    onPressed: () => Navigator.pushNamed(
                        context, '/productDetail',
                        arguments: product),
                    child: Text('Buy'),
                  ),
                ],
              )
            ],
          ),
        );
      }).toList(),
    );
  }
}
