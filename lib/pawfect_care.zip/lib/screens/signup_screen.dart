import 'package:flutter/material.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final phoneController = TextEditingController();
  final addressController = TextEditingController();
  final houseNumberController = TextEditingController();
  final descriptionController = TextEditingController();
  final allergyController = TextEditingController();

  List<Map<String, dynamic>> pets = [
    {
      'species': '',
      'breed': '',
      'gender': '',
      'isPregnant': false,
      'dob': null,
      'adoptionCert': '',
      'parentName': '',
      'parentAge': '',
      'isFirstTime': false,
      'vacDetails': '',
      'petImage': '',
      'lastWeight': ''
    }
  ];

  final List<String> speciesOptions = [
    'Dog',
    'Cat',
    'Bird',
    'Rabbit',
    'Hamster',
    'Fish',
    'Turtle',
    'Parrot',
    'Guinea Pig',
    'Iguana',
    'Ferret',
    'Sugar Glider',
    'Other'
  ];

  final Map<String, List<String>> breedMap = {
    'Dog': [
      'Labrador Retriever',
      'German Shepherd',
      'Pomeranian',
      'Beagle',
      'Doberman',
      'Golden Retriever',
      'Dachshund',
      'Indian Spitz',
      'Rajapalayam',
      'Mudhol Hound',
      'Other'
    ],
    'Cat': [
      'Persian',
      'Siamese',
      'Indian Billi',
      'Bengal',
      'Maine Coon',
      'Other'
    ],
    'Bird': [
      'Lovebird',
      'Budgie',
      'Cockatiel',
      'Macaw',
      'African Grey',
      'Other'
    ],
    'Rabbit': ['Angora', 'Dutch', 'Mini Lop', 'Other'],
    'Other': ['Other']
  };

  void addPet() {
    setState(() {
      pets.add({
        'species': '',
        'breed': '',
        'gender': '',
        'isPregnant': false,
        'dob': null,
        'adoptionCert': '',
        'parentName': '',
        'parentAge': '',
        'isFirstTime': false,
        'vacDetails': '',
        'petImage': '',
        'lastWeight': ''
      });
    });
  }

  void updatePet(int index, String key, dynamic value) {
    setState(() {
      pets[index][key] = value;
    });
  }

  void submitForm() {
    print("Name: ${nameController.text}");
    print("Email: ${emailController.text}");
    print("Password: ${passwordController.text}");
    print("Phone: ${phoneController.text}");
    print("Address: ${addressController.text}");
    print("House: ${houseNumberController.text}");
    print("Allergies: ${allergyController.text}");
    print("Desc: ${descriptionController.text}");
    print("Pets: $pets");
    Navigator.pop(context);
  }

  Widget buildPetForm(int index) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Pet ${index + 1}',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        TextField(
          decoration: const InputDecoration(labelText: 'Pet Parent Name'),
          onChanged: (val) => updatePet(index, 'parentName', val),
        ),
        TextField(
          decoration: const InputDecoration(labelText: 'Pet Parent Age'),
          onChanged: (val) => updatePet(index, 'parentAge', val),
        ),
        Row(
          children: [
            const Text("First Time Pet Parent?"),
            Checkbox(
              value: pets[index]['isFirstTime'] ?? false,
              onChanged: (val) => updatePet(index, 'isFirstTime', val),
            ),
          ],
        ),
        DropdownButtonFormField<String>(
          decoration: const InputDecoration(labelText: 'Species'),
          value:
              pets[index]['species'].isNotEmpty ? pets[index]['species'] : null,
          items: speciesOptions
              .map((spec) => DropdownMenuItem(value: spec, child: Text(spec)))
              .toList(),
          onChanged: (val) {
            updatePet(index, 'species', val);
            updatePet(index, 'breed', '');
          },
        ),
        pets[index]['species'].isNotEmpty &&
                breedMap.containsKey(pets[index]['species'])
            ? DropdownButtonFormField<String>(
                decoration: const InputDecoration(labelText: 'Breed'),
                value: pets[index]['breed'].isNotEmpty
                    ? pets[index]['breed']
                    : null,
                items: breedMap[pets[index]['species']]!
                    .map((breed) =>
                        DropdownMenuItem(value: breed, child: Text(breed)))
                    .toList(),
                onChanged: (val) => updatePet(index, 'breed', val),
              )
            : TextField(
                decoration: const InputDecoration(labelText: 'Breed (manual)'),
                onChanged: (val) => updatePet(index, 'breed', val),
              ),
        DropdownButtonFormField<String>(
          decoration: const InputDecoration(labelText: 'Gender'),
          value:
              pets[index]['gender'].isNotEmpty ? pets[index]['gender'] : null,
          items: const [
            DropdownMenuItem(value: 'Male', child: Text('Male')),
            DropdownMenuItem(value: 'Female', child: Text('Female')),
          ],
          onChanged: (val) => updatePet(index, 'gender', val),
        ),
        Row(
          children: [
            const Text("Pregnant?"),
            Switch(
              value: pets[index]['isPregnant'] ?? false,
              onChanged: (val) => updatePet(index, 'isPregnant', val),
            ),
          ],
        ),
        TextField(
          decoration:
              const InputDecoration(labelText: 'Date of Birth (YYYY-MM-DD)'),
          onChanged: (val) => updatePet(index, 'dob', val),
        ),
        TextField(
          decoration: const InputDecoration(
              labelText: 'Adoption Certificate Info (optional)'),
          onChanged: (val) => updatePet(index, 'adoptionCert', val),
        ),
        TextField(
          decoration: const InputDecoration(labelText: 'Vaccination Details'),
          onChanged: (val) => updatePet(index, 'vacDetails', val),
        ),
        TextField(
          decoration: const InputDecoration(labelText: 'Image URL (optional)'),
          onChanged: (val) => updatePet(index, 'petImage', val),
        ),
        TextField(
          decoration:
              const InputDecoration(labelText: 'Last Weighed Weight (kg)'),
          onChanged: (val) => updatePet(index, 'lastWeight', val),
        ),
        const Divider(),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sign Up')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Full Name')),
            TextField(
                controller: emailController,
                decoration: const InputDecoration(labelText: 'Email')),
            TextField(
                controller: passwordController,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Password')),
            TextField(
                controller: phoneController,
                decoration: const InputDecoration(labelText: 'Phone Number')),
            TextField(
                controller: houseNumberController,
                decoration: const InputDecoration(labelText: 'House Number')),
            TextField(
                controller: addressController,
                decoration: const InputDecoration(
                    labelText: 'Full Address / Location')),
            TextField(
                controller: allergyController,
                decoration:
                    const InputDecoration(labelText: 'Allergies (optional)')),
            TextField(
                controller: descriptionController,
                decoration: const InputDecoration(
                    labelText: 'Additional Description (optional)')),
            const SizedBox(height: 20),
            Column(
                children:
                    List.generate(pets.length, (index) => buildPetForm(index))),
            ElevatedButton.icon(
                onPressed: addPet,
                icon: const Icon(Icons.add),
                label: const Text("Add More Pets")),
            const SizedBox(height: 20),
            ElevatedButton(
                onPressed: submitForm, child: const Text("Create Account")),
          ],
        ),
      ),
    );
  }
}
