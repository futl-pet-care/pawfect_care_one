import 'package:flutter/material.dart';
import 'dating_screen.dart';
import 'grooming_screen.dart';
import 'training_screen.dart';
import 'more_services_screen.dart';
import 'dormitory_screen.dart';

class AppointmentScreen extends StatefulWidget {
  @override
  _AppointmentScreenState createState() => _AppointmentScreenState();
}

class _AppointmentScreenState extends State<AppointmentScreen> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    DatingScreen(),
    GroomingScreen(),
    TrainingScreen(),
    DormitoryScreen(),
    MoreServicesScreen(),
  ];

  final List<String> _titles = [
    'Dating',
    'Grooming',
    'Training',
    'Dormitory',
    'More Services',
  ];

  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_selectedIndex]),
        automaticallyImplyLeading: false,
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onTabTapped,
        selectedItemColor: Colors.teal,
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Dating',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.cut),
            label: 'Grooming',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.school),
            label: 'Training',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.house),
            label: 'Dormitory',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.more_horiz),
            label: 'More',
          ),
        ],
      ),
    );
  }
}
