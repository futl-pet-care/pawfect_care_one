import 'package:flutter/material.dart';

class PremiumScreen extends StatelessWidget {
  final List<Map<String, dynamic>> premiumServices = [
    {
      'title': 'DNA Testing',
      'description': 'Know your pet’s genetic history and traits.',
      'image': 'assets/dna_test.png'
    },
    {
      'title': 'True Breed Test',
      'description': 'Verify the breed authenticity of your pet.',
      'image': 'assets/breed_test.png'
    },
    {
      'title': 'Lost Pet Finder',
      'description': 'Use technology to locate your lost pet.',
      'image': 'assets/lost_pet.png'
    },
    {
      'title': 'Wearable Devices',
      'description': 'Track your pet’s health and movement.',
      'image': 'assets/wearable.png'
    },
    {
      'title': '24/7 Vet Care',
      'description': 'Get instant access to professional vet support.',
      'image': 'assets/247care.png'
    },
    {
      'title': 'Pet Wallet',
      'description': 'Manage your pet expenses and medical history.',
      'image': 'assets/wallet.png'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Premium Services')),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: premiumServices.length,
        itemBuilder: (context, index) {
          final service = premiumServices[index];
          return Card(
            margin: EdgeInsets.only(bottom: 16),
            elevation: 3,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  service['image'],
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                ),
              ),
              title: Text(service['title'],
                  style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(service['description']),
              trailing: Icon(Icons.arrow_forward_ios),
              onTap: () {
                // Navigate to respective premium service screen
                Navigator.pushNamed(context,
                    '/${service['title'].toLowerCase().replaceAll(' ', '_')}');
              },
            ),
          );
        },
      ),
    );
  }
}
