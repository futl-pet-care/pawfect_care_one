package com.example.pawfect_care

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
